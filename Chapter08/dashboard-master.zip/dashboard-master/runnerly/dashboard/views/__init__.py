from .home import home
from .proxy import proxy
from .auth import auth


blueprints = [home, proxy, auth]
