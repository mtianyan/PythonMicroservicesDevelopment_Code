Dashboard
=========

**DISCLAIMER** This repository is part of Runnerly, an application made for
the Python Microservices Development. It was made for educational
purpose and not suitable for production. It's still being updated.
If you find any issue or want to talk with the author, feel free to
open an issue in the issue tracker.


ReactJS-based application for Runnerly.

